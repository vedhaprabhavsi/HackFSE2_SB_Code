package com.estockmarket.query.domain.exception;

public class NoStocksExistsException extends RuntimeException {

}
