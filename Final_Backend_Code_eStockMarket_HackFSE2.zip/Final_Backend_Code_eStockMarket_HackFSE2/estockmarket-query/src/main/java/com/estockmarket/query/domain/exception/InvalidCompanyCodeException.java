package com.estockmarket.query.domain.exception;

public class InvalidCompanyCodeException extends RuntimeException {

}
